package com.windows;

import com.adminViews.ManageAdminView;
import com.customerViews.ManageCustomerView;
import com.runnerViews.ManageRunnerView;
import com.vendorViews.ManageVendorView;

public class OrderSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Login login = new Login();
                
//              this is with login page
//              to easy debug u can comment code above, and open ur certain view 
//		ManageVendorView manageVendor = new ManageVendorView();
//              ManageCustomerView managecustomer = new ManageCustomerView();
//              ManageRunnerView manageRunner = new ManageRunnerView();
	}

}
