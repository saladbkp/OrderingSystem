# OrderingSystem
JAVA -- Assignemnt

```
20231006
TextFunction -> readtext
Login

20231008
AdminVendorView
AdminCustomerView
CustomerTopUpView

20231009
TopUp + view customer 
runner view

20231010
add vendor 

20231012
add read modify delete function -> vendor /
set width as global par

20231015
admin done
```

