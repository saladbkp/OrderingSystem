package com.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.model.Customers;
import com.model.Order;
import com.tool.TextFunction;

public class AddOrderDao {
	ArrayList<Order> orderarray = new ArrayList<Order>();
	
	public AddOrderDao() {
		TextFunction txtfunc = new TextFunction("src/data/orders.txt");
		orderarray = txtfunc.readfile(Order.class);
	}

	// view
	public List<Order> findDataByCus(String id) {
		List<Order> findarray = this.orderarray.stream().filter(x->x.getCustomerId().equals(id)).toList();
		return findarray;
	}
	public List<Order> findDataByVen(String id) {
		List<Order> findarray = this.orderarray.stream().filter(x->x.getVendorId().equals(id)).toList();
		return findarray;
	}
	public List<Order> findDataByRun(String id) {
		List<Order> findarray = this.orderarray.stream().filter(x->x.getRunnerId().equals(id)).toList();
		return findarray;
	}
	public List<Order> findOrderData() {
		return this.orderarray;
	}
	public List<String> updateComboxCus() {
	    return orderarray.stream()
	                   .map(Order::getCustomerId).distinct()
	                   .collect(Collectors.toList());
	}
	public List<String> updateComboxVen() {
	    return orderarray.stream()
	                   .map(Order::getVendorId).distinct()
	                   .collect(Collectors.toList());
	}
	public List<String> updateComboxRun() {
	    return orderarray.stream()
	                   .map(Order::getRunnerId).distinct()
	                   .collect(Collectors.toList());
	}
	
}
