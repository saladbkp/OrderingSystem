//CONFIGURED
package com.model;


public class VendorFood {
                 private String vendorID;
//	private String vendorPwd;
//                 private String vendorName;
                 private String foodID;
                 private String foodName;
                 private double foodCost;
//               private int amount;

	
	public VendorFood(String vid,String fid,String fname,String foodcost) {
		this.vendorID = vid;

		this.foodID = fid;
		this.foodName = fname;
		this.foodCost = Double.parseDouble(foodcost);
	}
	public String getVendorID() {return this.vendorID;}
//	public String getVendorPwd() {return this.vendorPwd;}
//	public String getVendorName() {return this.vendorName;}
	public String getFoodID() {return this.foodID;}
                 public String getFoodName() {return this.foodName;}
                 public double getFoodCost(){return this.foodCost;}
                 public void setFoodCost(double foodcost) 
	{
		this.foodCost = foodcost;
	}

	public String toString() {
		String output = String.format("%s,%s,%s,%s,%s,%s", this.vendorID,this.foodID,this.foodName,this.foodCost);
		return output;
	}
}

