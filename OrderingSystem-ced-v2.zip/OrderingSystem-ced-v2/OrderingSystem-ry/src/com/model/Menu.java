//CONFIGURED

package com.model;

//need extends Vendor?
public class Menu {
	private String vendorID;
//	private String vendorName;
                  private String foodType;
	private int deliveryFee;

	
	public Menu(String id, String foodtype, String deliveryfee) {
		this.vendorID = id;
//		this.vendorName = name;
		this.foodType = foodtype;
		this.deliveryFee = Integer.parseInt(deliveryfee);
	}
	public String getVendorID() {return this.vendorID;}
//	public String getVendorName() {return this.vendorName;}
	public String getFoodType() {return this.foodType;}
                  public int getDeliveryFee(){return this.deliveryFee;}
	public void setDeliveryFee(int deliveryfee) 
	{
		this.deliveryFee = deliveryfee;
	}
        
                 public String toString() {
		String output = String.format("%s,%s,%s,%s,%s,%s", this.vendorID,this.foodType,this.deliveryFee);
		return output;
	}
        
        
}